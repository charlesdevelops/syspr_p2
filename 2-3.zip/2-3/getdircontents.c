#include "mysync.h"

void getDirContents(void)
{
    // logic
}